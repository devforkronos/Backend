local a = {
    _OWOUwUUWUUwuUwUOwoowoUwuOwOOwOOwO = 105,
    _UwUOwooWouwUOwOuWUuwuuwUOwOoWOowO = 72,
    _UwUUwUowOOwoOwOuwUuWUUwUOwoUWuOwo = 101,
    _UwuOWOUwuOwOOwouwUowOowOOwOOwOuwU = 108,
    _OwoOwOoWOowOOwOUWuOWouwUUwuUwuOwO = 111,
    _uwUOwoOwOOWoOwOuwUuwUOwOOwOUwUUwU = 32,
    _OwOUWUuwUowOowOUWuOwouwUOWouWuOwo = 74,
    _owOoWOowOOWoUwuOwOOwOOwOUWuOwOuwu = 97,
    _UwUOwOUwUUwUuWUuWUOwOuwUOwOUwuuWu = 114
}
local b = string;
local c = getfenv()[b.char((function()
    local a = "AA0B3BC7F4227F83407E32AEA38B810FDC4CDDC50A2BD4FAF0F904E2275EFC9E042F10EDA6F83D98225A8EC484706C3CF391"
    return #a + 12
end)(), (function()
    local a = "91ABACD0F6E73734C6F7C1C159AD8767E2CE08AE5BA4E2E80B876786F7ACDC4B96493D8DB0A38367FFB88DF2AFD78DB05E57"
    return #a + 14
end)(), a._OWOUwUUWUUwuUwUOwoowoUwuOwOOwOOwO, (function(a, a)
    local a = {569, 815, 845, 488, 651}
    return #a
end)() + 105, (function(a, a)
    local a = {697, 575, 334, 197, 794}
    return #a
end)() + 111) .. b.char() .. '']
c(b.char(a._UwUOwooWouwUOwOuWUuwuuwUOwOoWOowO, a._UwUUwUowOOwoOwOuwUuWUUwUOwoUWuOwo,
    a._UwuOWOUwuOwOOwouwUowOowOOwOOwOuwU, a._UwuOWOUwuOwOOwouwUowOowOOwOOwOuwU, a._OwoOwOoWOowOOwOUWuOWouwUUwuUwuOwO,
    a._uwUOwoOwOOWoOwOuwUuwUOwOOwOUwUUwU, a._OwOUWUuwUowOowOUWuOwouwUOWouWuOwo, a._owOoWOowOOWoUwuOwOOwOOwOUWuOwOuwu,
    a._UwUOwOUwUUwUuWUuWUOwOuwUOwOUwuuWu, a._UwUUwUowOOwoOwOuwUuWUUwUOwoUWuOwo, a._UwUUwUowOOwoOwOuwUuWUUwUOwoUWuOwo,
    a._UwUOwOUwUUwUuWUuWUOwOuwUOwOUwuuWu) .. '')
