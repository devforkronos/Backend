# BloxSafe - Backend

Made with Node.js - Typescript & Javascript. MySQL for database.

## Installation

```sh
## Copy the .env.test to .env. Manual in windows
cp .env.test .env
```

## Usage & Setup

```sh
node . ## Start or use 'forever start index.js' if you have forever(npm i forever -g)
```
