module.exports = function (req, res, next) {
    // Every request goes from thsi middleware
    next();
};
